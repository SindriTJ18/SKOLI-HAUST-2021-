#include <stdint.h> // Defines integer types of a particular size

int arr [1000];
//int8_t arr [1000];
//int16_t arr [1000];
//int32_t arr [1000];
//int64_t arr [1000];

int main(){
  // FILL UP ARRAY
  for (int i=0;i<1000;i++){
    arr[i] = 0;
  }
  return 0;
}
// ATH UNCOMMENT FYRIR MISMUNANDI INT TEST CASES
